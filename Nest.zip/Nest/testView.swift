//
//  testView.swift
//  Nest
//
//  Created by user on 11/10/23.
//

import SwiftUI

struct testView: View {
    var body: some View {
        Rectangle()
            .fill(Color(red: 0.9, green: 0.38, blue: 0.4))
    }
}

struct testView_Previews: PreviewProvider {
    static var previews: some View {
        testView()
    }
}
