//
//  NestApp.swift
//  Nest
//
//  Created by user on 10/10/23.
//

import SwiftUI

@main
struct NestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
